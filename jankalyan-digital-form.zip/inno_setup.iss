; ==============================================================================
; Inno Setup Script for Jankalyan Blood Bank Digital System (QF/JKRP/18)
; ==============================================================================
; Version: 1.0.0 (Updated with Port 8000 & IST Timezone Support)
; Requires: Inno Setup 6.x (Download free from: https://jrsoftware.org/isdl.php)
;
; Instructions:
; 1. First build the distribution folder on your development machine using:
;    build.bat   (or: python build_exe.py)
; 2. Place this file (inno_setup.iss) and the generated "dist" folder in the same directory.
; 3. Open this file in Inno Setup Compiler and click "Compile" (or press Ctrl+F9).
;    Or compile via command line:
;    iscc inno_setup.iss
; ==============================================================================

#define MyAppName "Jankalyan Blood Bank Digital System"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "Jankalyan Blood Centre & Hospital"
#define MyAppExeName "JankalyanBloodBank.exe"
#define MyAppURL "http://127.0.0.1:8000"

[Setup]
; Unique Application ID (GUID)
AppId={{C8E29910-3492-41FA-83DF-8F32C0D41BA2}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}
DefaultDirName={autopf}\Jankalyan Blood Bank
DefaultGroupName=Jankalyan Blood Bank
AllowNoIcons=yes
OutputDir=dist_installer
OutputBaseFilename=JankalyanBloodBank_Setup_v1.0
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog

; Visual Branding & Wizard Setup
DisableProgramGroupPage=auto
DisableReadyPage=no

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: checkedonce
Name: "quicklaunchicon"; Description: "Create a Quick Launch shortcut"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked; OnlyBelowVersion: 6.1; Check: not IsAdminInstallMode

[Files]
; All files compiled by PyInstaller into dist\JankalyanBloodBank
Source: "dist\JankalyanBloodBank\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
; Start Menu Shortcuts
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Comment: "Launch Jankalyan Blood Bank Digital System (Port 8000)"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"

; Desktop Shortcut
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon; Comment: "Launch Jankalyan Blood Bank Digital System (Port 8000)"

[Run]
; Option to launch the application immediately after setup finishes
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
; Clean up temporary logs if generated in application folder
Type: files; Name: "{app}\*.log"

[Code]
// Note: User database and logs stored in %APPDATA%\JankalyanBloodBank\data\ are safely preserved across updates and uninstalls.
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usPostUninstall then
  begin
    // User database preserved in %APPDATA%\JankalyanBloodBank\data\
  end;
end;
